# Add your API key
weather_api_key = "a5bbbb510853132138c82473f6b91e51"
